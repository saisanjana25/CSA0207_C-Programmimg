# LifeDrop — Every Drop Counts

LifeDrop is a student capstone interactive prototype for exploring donor registration, donor search, request tracking, a demo dashboard, donation history, notifications, donor cards, and analytics.

## Run locally
Open `www/index.html` in a modern browser.

## GitHub Pages
For a simple static GitHub Pages deployment, you can publish the `www` folder (or move `www/index.html` to the repository root if Pages is configured to publish from the root).

## Important prototype limitations
- Demo records and accounts are stored in browser local storage.
- Login/signup is not secure production authentication.
- The C backend is not connected to this single-file web prototype; its API address points to localhost.
- This is not a live blood service. It does not contact donors, hospitals, blood banks, or emergency services.
- Use fictional demo data only; do not enter real personal or medical information.
- QR generation references `qrcode.bundle.js`, which is not included in this upload. QR generation may therefore not work in this package.

## Project structure
- `www/index.html` — website UI, styles, and browser demo functionality in one file.
